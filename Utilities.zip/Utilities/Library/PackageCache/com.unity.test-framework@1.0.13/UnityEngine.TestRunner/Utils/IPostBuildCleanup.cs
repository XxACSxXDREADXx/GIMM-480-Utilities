namespace UnityEngine.TestTools
{
    public interface IPostBuildCleanup
    {
        void Cleanup();
    }
}
